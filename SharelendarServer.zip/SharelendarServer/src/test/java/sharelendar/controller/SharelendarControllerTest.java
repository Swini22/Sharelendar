package sharelendar.controller;

import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;

import sharelendar.model.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment= SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = {"spring.datasource.url=jdbc:hsqldb:mem:test","spring.datasource.username=sa", "spring.datasource.password=", "spring.datasource.driver-class-name=org.hsqldb.jdbcDriver", "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.HSQLDialect"})
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class, TransactionalTestExecutionListener.class, DbUnitTestExecutionListener.class})
public class SharelendarControllerTest {

	private static final SimpleDateFormat SIMPLEDATEFORMAT = new SimpleDateFormat("DD.MM.YYYY");
	
    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private SharelendarRepository sharelendarRepository;

    @Test
    @DatabaseSetup("/SharelendarRepositoryTestData.xml")
    public void allSchoolClasses(){
        List<SchoolClass> schoolClasses = restTemplate.getForObject("/AllSchoolClasses", ArrayList.class);
        assertEquals(3 ,schoolClasses.size());
    }

    @Test
    @DatabaseSetup("/SharelendarRepositoryTestData.xml")
    public void allEventsInSchoolClass(){
        int id = 1;
        List<Event> events = restTemplate.postForObject("/AllEventsInSchoolClass", id, ArrayList.class);
        
        assertEquals(2 ,events.size());
    }

    @Test
    @DatabaseSetup("/SharelendarRepositoryTestData.xml")
    public void checkUser(){
        AdminDTO adminDTO = new AdminDTO();
        adminDTO.setUsername("Admin");
        adminDTO.setPassword("1234");
        
        Boolean response = this.restTemplate.postForObject("/CheckAdmin", adminDTO, Boolean.class);
        
        assertEquals(true, response);
    }

    @Test
    @DatabaseSetup("/SharelendarRepositoryTestData.xml")
    public void createEvent() throws ParseException {
     	EventDTO eventDTO = new EventDTO();
    	eventDTO.setDate(SIMPLEDATEFORMAT.parse("17.11.2016"));
    	eventDTO.setInformation("Test Wirtschaft und Recht");
    
    	SchoolClass schoolClass = new SchoolClass();
    	schoolClass.setId(1);
    	schoolClass.setName("INF5H");
    	eventDTO.setSchoolClass(schoolClass);
    	
    	this.restTemplate.put("/CreateEvent", eventDTO);
    	List<Event> events = sharelendarRepository.getAllEventsBySchoolClassId(1);

        assertEquals(3 , events.size());
    }
    
    @Test
    @DatabaseSetup("/SharelendarRepositoryTestData.xml")
    public void updateEvent() throws ParseException {
     	Event event = new Event();
    	event.setId(1);
    	event.setDate(SIMPLEDATEFORMAT.parse("17.11.2016"));
    	event.setInformation("Test Wirtschaft und Recht");
    
    	SchoolClass schoolClass = new SchoolClass();
    	schoolClass.setId(1);
    	schoolClass.setName("INF5H");
    	event.setSchoolClass(schoolClass);
    	
    	this.restTemplate.put("/UpdateEvent", event);
    	List<Event> events = sharelendarRepository.getAllEventsBySchoolClassId(1);

        assertEquals(2 , events.size());
    }
    
    @Test
    @DatabaseSetup("/SharelendarRepositoryTestData.xml")
    public void deleteEvent() throws ParseException {
     	Event event = new Event();
    	event.setId(1);
    	event.setDate(SIMPLEDATEFORMAT.parse("17.11.2016"));
    	event.setInformation("Test Englisch");
    
    	SchoolClass schoolClass = new SchoolClass();
    	schoolClass.setId(1);
    	schoolClass.setName("INF5H");
    	event.setSchoolClass(schoolClass);
    	
    	this.restTemplate.delete("/DeleteEvent", event);
    	List<Event> events = sharelendarRepository.getAllEventsBySchoolClassId(1);

        assertEquals(2 , events.size());
    }
}