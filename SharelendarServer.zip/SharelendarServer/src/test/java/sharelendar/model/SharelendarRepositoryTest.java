package sharelendar.model;

import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import static org.junit.Assert.*;

@Transactional
@RunWith(SpringRunner.class)
@DataJpaTest()
@TestPropertySource(properties = {"spring.datasource.url=jdbc:hsqldb:mem:test","spring.datasource.username=sa", "spring.datasource.password=", "spring.datasource.driver-class-name=org.hsqldb.jdbcDriver", "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.HSQLDialect"})

@TestExecutionListeners({DependencyInjectionTestExecutionListener.class, TransactionalTestExecutionListener.class, DbUnitTestExecutionListener.class})
public class SharelendarRepositoryTest {
	
	private static final SimpleDateFormat SIMPLEDATEFORMAT = new SimpleDateFormat("DD.MM.YYYY");

    @Autowired
    private TestEntityManager em;

    @Autowired
    private SharelendarRepository sharelendarRepository;

    @Test
    @DatabaseSetup("/SharelendarRepositoryTestData.xml")
    public void getAllSchoolClasses() {
    	List<SchoolClass> schoolClasses = sharelendarRepository.getAllSchoolClasses();
        assertEquals(3, schoolClasses.size());
    }

    @Test
    @DatabaseSetup("/SharelendarRepositoryTestData.xml")
    public void getAllEventsBySchoolClassId() {
    	int id = 1;
        List<Event> events = sharelendarRepository.getAllEventsBySchoolClassId(id);
        assertEquals(2, events.size());
    }

    @Test
    @DatabaseSetup("/SharelendarRepositoryTestData.xml")
    public void checkAdmin() {
        String username = "Admin";
        String password = "7110eda4d09e062aa5e4a390b0a572ac0d2c0220";

        Admin admin = sharelendarRepository.checkAdmin(username, password);

        assertEquals(username, admin.getUsername());
    }

    @Test
    @DatabaseSetup("/SharelendarRepositoryTestData.xml")
    public void createEvent() throws ParseException{
    	Event event = new Event();
    	event.setDate(SIMPLEDATEFORMAT.parse("17.11.2016"));
    	event.setInformation("Test Wirtschaft und Recht");
    	
    	SchoolClass schoolClass = new SchoolClass();
    	schoolClass.setId(1);
    	schoolClass.setName("INF5H");
    	event.setSchoolClass(schoolClass);
    	
    	Event resultEvent = sharelendarRepository.createEvent(event);
        assertEquals(event, resultEvent);
    }

    @Test
    @DatabaseSetup("/SharelendarRepositoryTestData.xml")
    public void updateEvent() throws ParseException {
    	Event event = new Event();
    	event.setId(1);
    	event.setDate(SIMPLEDATEFORMAT.parse("17.11.2016"));
    	event.setInformation("Test Wirtschaft und Recht");
    
    	SchoolClass schoolClass = new SchoolClass();
    	schoolClass.setId(1);
    	schoolClass.setName("INF5H");
    	event.setSchoolClass(schoolClass);
   
    	Event resultEvent = sharelendarRepository.updateEvent(event);
        assertEquals(event, resultEvent);
    }
    

    @Test
	@DatabaseSetup("/SharelendarRepositoryTestData.xml")
	public void deleteEvent() throws ParseException {
    	Event event = new Event();
    	event.setId(1);
    	event.setDate(SIMPLEDATEFORMAT.parse("15.05.2016"));
    	event.setInformation("Test Englisch");
    	
    	SchoolClass schoolClass = new SchoolClass();
    	schoolClass.setId(1);
    	schoolClass.setName("INF5H");
    	event.setSchoolClass(schoolClass);
    	
    	sharelendarRepository.deleteEvent(event);
    	
        List<Event> events = sharelendarRepository.getAllEventsBySchoolClassId(1);
        assertEquals(1, events.size());
	}
}