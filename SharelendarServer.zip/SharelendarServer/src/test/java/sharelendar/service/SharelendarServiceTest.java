package sharelendar.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.verify;

import sharelendar.model.Event;
import sharelendar.model.EventDTO;
import sharelendar.model.SchoolClass;
import sharelendar.model.SharelendarRepository;
import sharelendar.service.SharelendarService;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class SharelendarServiceTest {

	private static final SimpleDateFormat SIMPLEDATEFORMAT = new SimpleDateFormat("DD.MM.YYYY");

	@Captor
    private ArgumentCaptor<Event> eventCaptor;
	
	@Mock
	private SharelendarRepository sharelendarRepository;
	
    @InjectMocks
    private SharelendarService sharelendarService = new SharelendarService();
	  
    @Test
    public void encryptPassword() throws NoSuchAlgorithmException, UnsupportedEncodingException{
    	String crypt = SharelendarService.encryptPassword("1234");
    	
    	assertEquals("7110eda4d09e062aa5e4a390b0a572ac0d2c0220",crypt);
    }
    
    @Test
    public void createEvent() throws ParseException{
    	EventDTO eventDTO = new EventDTO();
    	eventDTO.setDate(SIMPLEDATEFORMAT.parse("17.11.2016"));
    	eventDTO.setInformation("Test Wirtschaft und Recht");
    
    	SchoolClass schoolClass = new SchoolClass();
    	schoolClass.setId(1);
    	schoolClass.setName("INF5H");
    	eventDTO.setSchoolClass(schoolClass); 	
    	
    	sharelendarService.createEvent(eventDTO);
    	
    	verify(sharelendarRepository).createEvent(eventCaptor.capture());

    	assertEquals(eventDTO.getSchoolClass(), eventCaptor.getValue().getSchoolClass());
    }
}