package sharelendar.model;

import javax.persistence.*;

@Entity
@Table(name = "ADMIN_SCHOOLCLASS")
public class Admin_SchoolClass {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "FK_SCHOOLCLASS")
    private SchoolClass schoolClass;

    @ManyToOne
    @JoinColumn(name = "FK_ADMIN")
    private Admin admin;


    // -----Konstruktor------
    public Admin_SchoolClass() {
        super();
    }

    // --------Getter---------
    public int getId() {
        return id;
    }

    public SchoolClass getSchoolClass() {
        return schoolClass;
    }

    public Admin getAdmin() {
        return admin;
    }

    // --------Setter---------
    public void setId(Integer id) {
        this.id = id;
    }

    public void setSchoolClass(SchoolClass schoolClass) {
        this.schoolClass = schoolClass;
    }

    public void setAdmin(Admin admin) {
        this.admin = admin;
    }

    @Override
    public String toString() {
        String result = "Number: " + (id + 1) + "\n";
        return result;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Admin_SchoolClass other = (Admin_SchoolClass) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }
}
