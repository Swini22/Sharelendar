package sharelendar.model;

import javax.persistence.Column;

public class AdminDTO {

	private String username;
	private String password;

	// -----Konstruktor------
	public AdminDTO() {
		super();
	}

	// --------Getter---------
	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	// --------Setter---------
	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
