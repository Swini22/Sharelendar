package sharelendar.model;

import java.util.List;

public interface SharelendarRepository {
	
    List<SchoolClass> getAllSchoolClasses();
    
    List<Event> getAllEventsBySchoolClassId(int id);

    Admin checkAdmin(String username, String password);

    Event createEvent(Event event);
    
    Event updateEvent(Event event);
    
    void deleteEvent(Event event);
}
