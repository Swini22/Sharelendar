package sharelendar.model;

import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import java.util.List;

@Repository
public class SharelendarRepositoryImpl implements SharelendarRepository {

    @PersistenceContext
    EntityManager em;

	@Override
	public List<SchoolClass> getAllSchoolClasses() {
	     List<SchoolClass> schoolClasses = null;
	     TypedQuery<SchoolClass> query = em.createQuery("from SchoolClass", SchoolClass.class);
	     schoolClasses = query.getResultList();
	     return schoolClasses;
	}

	@Override
	public List<Event> getAllEventsBySchoolClassId(int id) {
	     List<Event> events = null;
	     TypedQuery<Event> query = em.createQuery("from Event where schoolClass.id =:id", Event.class);
	     query.setParameter("id", id);
	     events = query.getResultList();
	     return events;
	}

	@Override
	public Admin checkAdmin(String username, String password) {
		TypedQuery<Admin> query = em.createQuery("from Admin where username =:username AND password =:password ", Admin.class);
        query.setParameter("username", username);
        query.setParameter("password", password);
        Admin admin = query.getSingleResult();
 
        return admin;
	}

	@Override
	public Event createEvent(Event event) {
        em.persist(event);
        return event;
	}

	@Override
	public Event updateEvent(Event event) {
		event = em.merge(event);
        return event;
	}

	@Override
	public void deleteEvent(Event event) {
		Event toDeleteEvent = em.find(Event.class, event.getId());
		em.remove(toDeleteEvent);
	}
}

