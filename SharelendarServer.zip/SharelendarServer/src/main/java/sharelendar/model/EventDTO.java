package sharelendar.model;

import java.util.Date;

public class EventDTO {

    private Date date;
    private String information;
    private SchoolClass schoolClass;


    // -----Konstruktor------
    public EventDTO() {
        super();
    }

    // --------Getter---------
    public SchoolClass getSchoolClass() {
        return schoolClass;
    }

    public Date getDate() {
		return date;
	}

	public String getInformation() {
		return information;
	}

	// --------Setter---------
    public void setSchoolClass(SchoolClass schoolClass) {
        this.schoolClass = schoolClass;
    }

    public void setDate(Date date) {
		this.date = date;
	}

	public void setInformation(String information) {
		this.information = information;
	}
}
