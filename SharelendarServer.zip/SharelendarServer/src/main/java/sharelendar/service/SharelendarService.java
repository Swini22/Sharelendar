package sharelendar.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import sharelendar.model.Admin;
import sharelendar.model.AdminDTO;
import sharelendar.model.Event;
import sharelendar.model.EventDTO;
import sharelendar.model.SchoolClass;
import sharelendar.model.SharelendarRepository;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;


@Transactional
@Service("SharelendarService")
public class SharelendarService {
	
	private static final Logger LOG = Logger.getLogger(SharelendarService.class);

    @Autowired
    SharelendarRepository sharelendarRepository;

    public List<SchoolClass> getAllSchoolClasses() {
        return sharelendarRepository.getAllSchoolClasses();
    }
    
    public List<Event> getAllEventsBySchoolClassId(int id) {
        return sharelendarRepository.getAllEventsBySchoolClassId(id);
    }

    public Event createEvent(EventDTO eventDTO) {
    	Event event = new Event();
    	event.setDate(eventDTO.getDate());
    	event.setInformation(eventDTO.getInformation());
    	event.setSchoolClass(eventDTO.getSchoolClass());
    	
        return sharelendarRepository.createEvent(event);
    }

    public Event updateEvent(Event event){
        return sharelendarRepository.updateEvent(event);
    }
    
    public void deleteEvent(Event event){
        sharelendarRepository.deleteEvent(event);
    }
    
    public boolean checkAdmin(AdminDTO adminDTO){
    	try {
        	String pw = encryptPassword(adminDTO.getPassword());
            Admin resultAdmin = sharelendarRepository.checkAdmin(adminDTO.getUsername(), pw);
            return resultAdmin!= null;
		} catch (Exception e) {
			LOG.error(e);
		}
    	return false;
    }
    
    static String encryptPassword(String password) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest crypt = MessageDigest.getInstance("SHA-1");
        crypt.reset();
        crypt.update(password.getBytes("UTF-8"));

        return new BigInteger(1, crypt.digest()).toString(16);
    }
}