package sharelendar.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import sharelendar.model.AdminDTO;
import sharelendar.model.Event;
import sharelendar.model.EventDTO;
import sharelendar.model.SchoolClass;
import sharelendar.service.SharelendarService;

import java.util.List;

@RestController
@Service
public class SharelendarController {

    @Autowired
    private SharelendarService sharelendarService;

    @RequestMapping("/AllSchoolClasses")
    public List<SchoolClass> allSschoolClasses() {
        return sharelendarService.getAllSchoolClasses();
    }

    @PostMapping("/AllEventsInSchoolClass")
    public List<Event> allEventsInSchoolClass(@RequestBody int id) {
        return sharelendarService.getAllEventsBySchoolClassId(id);
    }

    @PutMapping("/CreateEvent")
    public Event createEvent(@RequestBody EventDTO eventDTO){
        return sharelendarService.createEvent(eventDTO);
    }
    
    @PutMapping("/UpdateEvent")
    public Event updateEvent(@RequestBody Event event){
        return sharelendarService.updateEvent(event);
    }
    
    @DeleteMapping("/DeleteEvent")
    public void deleteEvent(@RequestBody Event event){
        sharelendarService.deleteEvent(event);
    }
    
    @PostMapping("/CheckAdmin")
    public boolean checkAdmin(@RequestBody AdminDTO adminDTO){
        return sharelendarService.checkAdmin(adminDTO);
    }
}